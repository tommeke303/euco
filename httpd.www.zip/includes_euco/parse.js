$(window).ready(function() {
    $("#header-wrap").load("includes_euco/menu.html")    
})